﻿using System;

using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WMGooglemaps
{
    public partial class FormSelectDisplayWP : Form
    {
        ArrayList wayPointsCBList;
        form1 mainForm;
        String allWPTypes;
        String selectedWPTypes;

        public FormSelectDisplayWP(form1 parent)
        {
            InitializeComponent();
            mainForm = parent;

            bok.Location = new System.Drawing.Point(this.Width - bok.Width - 10, this.Height - bok.Height - 20);
            panelcb.Width =  this.Width - panelcb.Location.X;
            panelcb.Height = bok.Location.Y - panelcb.Location.Y - 10;

            selectedWPTypes = mainForm.getSelectedWPTypes().ToUpper();
            allWPTypes = mainForm.getAllWPTypes().ToUpper();

            if (!mainForm.isFlagDrawWayPoints())
            {
                rb_none.Checked = true;
                panelcb.Enabled = false;
            }
            else if (mainForm.isFlagDrawAllWayPoints())
            {
                rb_all.Checked = true;
                panelcb.Enabled = false;
            }
            else
            {
                rb_selected.Checked = true;
                panelcb.Enabled = true;
            }

            wayPointsCBList = new ArrayList(allWPTypes.Length);
            int lastcbX = -1;
            int lastcbY = 0;
            int cbHeight = checkBox1.Height;
            checkBox1.Visible = false;

            for (int idx = 0; idx < allWPTypes.Length; idx++)
            {
                CheckBox cb = new CheckBox();
                cb.Text = allWPTypes.Substring(idx, 1);
                cb.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);

                panelcb.Controls.Add(cb);
                wayPointsCBList.Add(cb);

                if (lastcbX == -1)
                {
                    // we have new CB
                    lastcbX = 10;
                    lastcbY = 10;
                }
                else
                {
                    lastcbY = lastcbY + 10 + checkBox1.Height;
                }

                if ((lastcbY + cbHeight + 10) > panelcb.Height)
                {
                    // we have second column
                    lastcbX = panelcb.Width / 2;
                        lastcbY = 10;
                }

                cb.Location = new System.Drawing.Point(lastcbX, lastcbY);
                cb.Width = 120;
                cb.Height = cbHeight;

                if (selectedWPTypes.IndexOf(allWPTypes.Substring(idx, 1)) > -1)
                {
                    cb.Checked = true;
                } 
                else 
                {
                    cb.Checked = false;
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        public string getSelectedWPTypes()
        {
            String ret = "";
            foreach (CheckBox wp in wayPointsCBList)
            {
                if (wp.Checked)
                {
                    ret = ret + wp.Text.Substring(0, 1).ToUpper();
                }
            }
            return ret;
        }

        public bool isNoneSelected()
        {
            if (rb_none.Checked)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool isSelectedSelected()
        {
            if (rb_selected.Checked)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool isAllSelected()
        {
            if (rb_all.Checked)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void rb_none_CheckedChanged(object sender, EventArgs e)
        {
            panelcb.Enabled = false;
            //Close();
        }

        private void rb_selected_CheckedChanged(object sender, EventArgs e)
        {
            panelcb.Enabled = true;
        }

        private void rb_all_CheckedChanged(object sender, EventArgs e)
        {
            panelcb.Enabled = false;
            //Close();
        }

    }
}