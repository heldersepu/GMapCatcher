﻿namespace WMGooglemaps
{
    partial class FormSelectMap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.bcancel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panelSelectMap = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // bcancel
            // 
            this.bcancel.Location = new System.Drawing.Point(154, 233);
            this.bcancel.Name = "bcancel";
            this.bcancel.Size = new System.Drawing.Size(72, 20);
            this.bcancel.TabIndex = 0;
            this.bcancel.Text = "Cancel";
            this.bcancel.Click += new System.EventHandler(this.bcancel_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(33, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 20);
            this.label1.Text = "Select map:";
            // 
            // panelSelectMap
            // 
            this.panelSelectMap.Location = new System.Drawing.Point(15, 54);
            this.panelSelectMap.Name = "panelSelectMap";
            this.panelSelectMap.Size = new System.Drawing.Size(210, 164);
            // 
            // FormSelectMap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.panelSelectMap);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bcancel);
            this.Menu = this.mainMenu1;
            this.Name = "FormSelectMap";
            this.Text = "FormSelectMap";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bcancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelSelectMap;
    }
}