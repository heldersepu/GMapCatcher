﻿using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WMGooglemaps
{
    public partial class FormStoreWaypoint : Form
    {
        bool save = false;
        form1 mainForm;

        public FormStoreWaypoint(form1 parent)
        {

            InitializeComponent();
            mainForm = parent;
            
            // fill combobox with colors
            for (int i = 0; i < WayPoint.colorsNames.Length; i++)
            {
                cb_color.Items.Add(WayPoint.colorsNames[i]);
            }
            cb_color.SelectedIndex = 0;

            double lat, lon;
            parent.getCurrentCoordsGPS(out lat, out lon);
            lat = Math.Round(lat, 5);
            lon = Math.Round(lon, 5);
            tb_lat.Text = lat.ToString();
            tb_lon.Text = lon.ToString();

            tb_wptype.Text = "U";

            tb_time.Text = DateTime.Now.ToString("G");

            tb_name.Focus();
        }

        private void b_cancel_Click(object sender, EventArgs e)
        {
            save = false;
            Close();
        }

        public bool isSave()
        {
            return save;
        }

        public string getLat()
        {
            return tb_lat.Text;
        }
        public string getLon()
        {
            return tb_lon.Text;
        }
        public string getName()
        {
            return tb_name.Text;
        }
        public string getNote()
        {
            return tb_note.Text;
        }
        public string getTStamp()
        {
            return tb_time.Text;
        }
        public string getColor()
        {
            return cb_color.SelectedItem.ToString();
        }

        public string getWPType()
        {
            if (tb_wptype.Text.Length == 0)
            {
                return mainForm.getDefaultWPType().Substring(0, 1);
            }
            return tb_wptype.Text.Substring(0,1).ToUpper();
        }


        private void b_save_Click(object sender, EventArgs e)
        {
            save = true;
            if (tb_name.Text.Trim().Equals(""))
            {
                tb_name.Text = tb_time.Text;
            }
            Close();
        }

    }
}