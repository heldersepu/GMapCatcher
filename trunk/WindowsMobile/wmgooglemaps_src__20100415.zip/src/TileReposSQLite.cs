﻿using System;

using System.Collections;
using System.Text;
using System.Drawing;
using System.IO;
using System.Data.SQLite;


//SQL_DATABASE_DDL = "CREATE TABLE tiles (x INTEGER, y INTEGER,zoom INTEGER,layer INTEGER, tstamp INTEGER, img BLOB, PRIMARY KEY(x,y,zoom,layer));"

namespace WMGooglemaps
{
    class TileReposSQLite : ITileRepos
    {
        Hashtable layerId_layer;
        ArrayList currentLayers;
        LayerInfo currentLayer;
        
        SQLiteConnection sql_cnn = null;

        bool initialized;
        string dbfilename;

        form1 f;

        public TileReposSQLite(form1 f)
        {
            this.f = f;
            layerId_layer = TileReposFactory.getLayerId_layer();

            initialized = false;
            dbfilename = f.getSelectedMapPath() + "\\" + form1.sqliteTilesRepository;
            initTilesLayers();
        }

        ~TileReposSQLite()
        {
            sql_cnn.Close();
        }

            public ArrayList getLayers()
        {
            return currentLayers;
        }

        Int64 getTilesRepositoryFileSize()
        {
            FileInfo fi = new FileInfo(dbfilename);
            return fi.Length;
        }

        ArrayList getTilesLayersFromFile()
        {
            string filepath = f.getSelectedMapPath() + "\\" + form1.sqliteTilesRepositoryLayers;
            if (!File.Exists(filepath))
            {
                throw new RepositoryOtherException("File doesn't exist: " + filepath);
            }

            ArrayList currentLayers = null;

            // Create an instance of StreamReader to read from a file.
            // The using statement also closes the StreamReader.
            using (StreamReader sr = new StreamReader(filepath))
            {
                String line;
                if ((line = sr.ReadLine()) != null)
                {

                    string[] parts;
                    parts = line.Trim().Split(':');

                    if (parts.Length < 2)
                    {
                        throw new RepositoryOtherException("Invalid content of the file: " + filepath);
                    }

                    try
                    {
                        currentLayers = new ArrayList(parts.Length - 1);
                        Int64 fsize = Int64.Parse(parts[0]);
                        if (fsize != getTilesRepositoryFileSize())
                        {
                            throw new RepositoryOtherException("TilesRepository filesize changed. Old size: " + fsize.ToString());
                        }

                        for (int i = 1; i < parts.Length; i++)
                        {
                            int lrid = Int32.Parse(parts[i]);
                            LayerInfo l;
                            if (layerId_layer.ContainsKey(lrid))
                            {
                                l = (LayerInfo)layerId_layer[lrid];
                                currentLayers.Add(l);
                            }
                            else
                            {
                                //TODO: let the user know that we don't have lrid in known layers
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new RepositoryOtherException("Error while parsing file: " + filepath, ex);
                    }
                }
                else
                {
                    throw new RepositoryOtherException("File " + filepath + " doesn't contain data.");
                }
            }


            return currentLayers;
        }

        void initTilesLayersFile()
        {
            try
            {
                ArrayList al = new ArrayList(2);
                al.Add(getTilesRepositoryFileSize().ToString());

                sql_cnn = new SQLiteConnection("Data Source=" + dbfilename);
                sql_cnn.Open();

                SQLiteCommand mycommand = new SQLiteCommand(sql_cnn);
                mycommand.CommandText = "SELECT layer FROM tiles GROUP BY layer";
                SQLiteDataReader rdr = mycommand.ExecuteReader();

                if (!rdr.HasRows)
                {
                    initialized = false;
                    return;
                }

                while (rdr.Read())
                {
                    al.Add(rdr.GetInt32(0).ToString());
                }

                string sep = "";
                string toFile = "";
                foreach( string val in al)
                {
                    toFile = String.Concat(toFile, sep, val);
                    sep = ":";
                }

                try
                {
                    using (StreamWriter outfile =
                        new StreamWriter(f.getSelectedMapPath() + "\\" + form1.sqliteTilesRepositoryLayers))
                    {
                        outfile.Write(toFile);
                    }
                }
                catch (Exception exc)
                {
                    throw new RepositoryOtherException("Unable to create file: " + f.getSelectedMapPath() + "\\" + form1.sqliteTilesRepositoryLayers, exc);
                }
            }
            catch (Exception e)
            {
                throw new RepositoryOtherException("Error getting layers list from: " + f.getSelectedMapPath() + "\\" + form1.sqliteTilesRepository, e);
            }
        }


        /**
         * if we have file form1.sqliteTilesRepository, then get layer ids from the file
         * otherwise generate file
         */
        void initTilesLayers()
        {
            try
            {
                try
                {
                    currentLayers = getTilesLayersFromFile();
                    initialized = true;
                }
                catch (RepositoryOtherException)
                {
                    //if (File.Exists(f.getSelectedMapPath() + "\\" + form1.sqliteTilesRepositoryLayers))
                    //{
                    //    File.Delete(f.getSelectedMapPath() + "\\" + form1.sqliteTilesRepositoryLayers);
                    //}
                    initTilesLayersFile();
                    currentLayers = getTilesLayersFromFile();
                    initialized = true;
                }
            }
            catch (Exception e)
            {
                initialized = false;
                throw new RepositoryNotInitializedException("Initialization error.", e);
            }


        }

        Bitmap getTileFromDB(int lzoom, int ltilex, int ltiley)
        {
            SQLiteDataReader rdr;
            try
            {
                if (sql_cnn == null)
                {
                    sql_cnn = new SQLiteConnection("Data Source=" + dbfilename);
                    sql_cnn.Open();
                }
                SQLiteCommand mycommand = new SQLiteCommand(sql_cnn);
                // x INTEGER, y INTEGER,zoom INTEGER,layer INTEGER, tstamp INTEGER, img BLOB
                string sqlcommand = "SELECT img FROM tiles WHERE layer=" + currentLayer.Id + " AND x=" + ltilex.ToString() + " AND y=" + ltiley.ToString() + " AND zoom=" + lzoom.ToString();
                mycommand.CommandText = sqlcommand;
                rdr = mycommand.ExecuteReader();
            }
            catch (Exception e)
            {
                throw new RepositoryOtherException("SQLite exception.", e);
            }

            if (!rdr.HasRows)
            {
                return null;
            }

            try
            {
                rdr.Read();
                long length = rdr.GetBytes(0, 0, null, 0, 0);
                byte[] myBinaryData = new byte[length];
                rdr.GetBytes(0, 0, myBinaryData, 0, myBinaryData.Length);

                return new Bitmap(new MemoryStream(myBinaryData));
            }
            catch (Exception e)
            {
                throw new RepositoryOtherException("SQLite exception.", e);
            }
            
        }


        public Bitmap getTile(int lzoom, int ltilex, int ltiley)
        {
            if (!initialized)
            {
                //TODO: use different kind of exception
                throw new Exception("Not initialized.");
            }

            //string tileHash = ReposID + ":" + lzoom.ToString() + ":" + ltilex.ToString() + ":" + ltiley.ToString();
            Bitmap btm = getTileFromDB(lzoom, ltilex, ltiley);

            if (btm == null)
            {
                throw new TileNotFoundException("Tile not found z:x:y: " + lzoom.ToString() + ":" + ltilex.ToString() + ":" + ltiley.ToString() );
            }
            return btm;
        }

        public void setTilesLayer(string textID)
        {
            if (!initialized)
            {
                throw new RepositoryNotInitializedException("Not initialized.");
            }

            foreach (LayerInfo li in currentLayers)
            {
                if (li.TextID.Equals(textID))
                {
                    currentLayer = li;
                    return;
                }
            }
            throw new LayerNotExistsException("Layer '" + textID + "' was not found!");
        }

        public void setTilesLayer()
        {
            if (!initialized)
            {
                throw new RepositoryNotInitializedException("Not initialized.");
            }

            foreach (LayerInfo li in currentLayers)
            {
                currentLayer = li;
                return;
            }
            throw new LayerNotExistsException("No layer was found!");
        }

        public string getTilesDirsCurrent()
        {
            if (!initialized)
            {
                throw new RepositoryNotInitializedException("Not initialized.");
            }

            return currentLayer.LayerDir;
        }

        public string getReposID()
        {
            if (!initialized)
            {
                return ":";
            }
            try
            {
                return f.getSelectedMapPath() + ":" + currentLayer.LayerDir;
            }
            catch (NullReferenceException)
            {
                return ":";
            }
        }

        public bool isInitialized()
        {
            return initialized;
        }
        public string getLayerTextID()
        {
            if (!initialized)
            {
                return "";
            }
            try
            {
                return currentLayer.TextID;
            }
            catch (NullReferenceException)
            {
                return "";
            }
        }
    }
}


