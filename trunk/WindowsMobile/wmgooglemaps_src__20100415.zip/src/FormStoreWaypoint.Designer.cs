﻿namespace WMGooglemaps
{
    partial class FormStoreWaypoint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_lat = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_lon = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_time = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cb_color = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_note = new System.Windows.Forms.TextBox();
            this.b_cancel = new System.Windows.Forms.Button();
            this.b_save = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.tb_name = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tb_wptype = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(3, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 20);
            this.label1.Text = "Store Waypoint:";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(3, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 20);
            this.label2.Text = "Lat:";
            // 
            // tb_lat
            // 
            this.tb_lat.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular);
            this.tb_lat.Location = new System.Drawing.Point(48, 51);
            this.tb_lat.Name = "tb_lat";
            this.tb_lat.Size = new System.Drawing.Size(70, 24);
            this.tb_lat.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(126, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 20);
            this.label3.Text = "Lon:";
            // 
            // tb_lon
            // 
            this.tb_lon.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular);
            this.tb_lon.Location = new System.Drawing.Point(160, 51);
            this.tb_lon.Name = "tb_lon";
            this.tb_lon.Size = new System.Drawing.Size(77, 24);
            this.tb_lon.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(3, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 20);
            this.label4.Text = "Time:";
            // 
            // tb_time
            // 
            this.tb_time.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular);
            this.tb_time.Location = new System.Drawing.Point(48, 82);
            this.tb_time.Name = "tb_time";
            this.tb_time.Size = new System.Drawing.Size(116, 24);
            this.tb_time.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(3, 179);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 20);
            this.label5.Text = "Color:";
            // 
            // cb_color
            // 
            this.cb_color.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular);
            this.cb_color.Location = new System.Drawing.Point(48, 176);
            this.cb_color.Name = "cb_color";
            this.cb_color.Size = new System.Drawing.Size(189, 25);
            this.cb_color.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(3, 148);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 20);
            this.label6.Text = "Note:";
            // 
            // tb_note
            // 
            this.tb_note.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular);
            this.tb_note.Location = new System.Drawing.Point(48, 144);
            this.tb_note.Name = "tb_note";
            this.tb_note.Size = new System.Drawing.Size(189, 24);
            this.tb_note.TabIndex = 10;
            // 
            // b_cancel
            // 
            this.b_cancel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.b_cancel.Location = new System.Drawing.Point(14, 226);
            this.b_cancel.Name = "b_cancel";
            this.b_cancel.Size = new System.Drawing.Size(68, 31);
            this.b_cancel.TabIndex = 11;
            this.b_cancel.Text = "Cancel";
            this.b_cancel.Click += new System.EventHandler(this.b_cancel_Click);
            // 
            // b_save
            // 
            this.b_save.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.b_save.Location = new System.Drawing.Point(104, 221);
            this.b_save.Name = "b_save";
            this.b_save.Size = new System.Drawing.Size(109, 39);
            this.b_save.TabIndex = 12;
            this.b_save.Text = "Save";
            this.b_save.Click += new System.EventHandler(this.b_save_Click);
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(3, 117);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 20);
            this.label7.Text = "Name:";
            // 
            // tb_name
            // 
            this.tb_name.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular);
            this.tb_name.Location = new System.Drawing.Point(48, 112);
            this.tb_name.Name = "tb_name";
            this.tb_name.Size = new System.Drawing.Size(189, 24);
            this.tb_name.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(170, 86);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(28, 20);
            this.label8.Text = "Tp:";
            // 
            // tb_wptype
            // 
            this.tb_wptype.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular);
            this.tb_wptype.Location = new System.Drawing.Point(204, 82);
            this.tb_wptype.Name = "tb_wptype";
            this.tb_wptype.Size = new System.Drawing.Size(33, 24);
            this.tb_wptype.TabIndex = 32;
            // 
            // FormStoreWaypoint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.tb_wptype);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.tb_name);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.b_save);
            this.Controls.Add(this.b_cancel);
            this.Controls.Add(this.tb_note);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cb_color);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tb_time);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tb_lon);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tb_lat);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Menu = this.mainMenu1;
            this.Name = "FormStoreWaypoint";
            this.Text = "FormStoreWaypoint";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_lat;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_lon;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_time;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cb_color;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_note;
        private System.Windows.Forms.Button b_cancel;
        private System.Windows.Forms.Button b_save;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tb_name;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tb_wptype;
    }
}