﻿using System;

using System.Collections;
using System.Text;
using System.IO;

namespace WMGooglemaps
{
    internal class TileReposFactory
    {

        static Hashtable layerDir_layer;
        static Hashtable layerId_layer;

        public static Hashtable getLayerDir_layer()
        {
            return layerDir_layer;
        }
        public static Hashtable getLayerId_layer()
        {
            return layerId_layer;
        }
        /*
        public static ArrayList getCurrentLayers()
        {
            return currentLayers;
        }
         */
        
        static TileReposFactory()
        {
            LayerInfo lr;
            layerDir_layer = new Hashtable();
            layerId_layer = new Hashtable();

            /*
             * 20100304:
    MAP_SERVICES_PLAIN = [
                          {"ID": 0, "TextID": "gmap", "serviceName":"Google", "layerDir": "tiles", "layerName": "Map" },
                          {"ID": 1, "TextID": "gsat", "serviceName":"Google", "layerDir": "sat_tiles", "layerName": "Satellite" },
                          {"ID": 2, "TextID": "gter", "serviceName":"Google", "layerDir": "ter_tiles", "layerName": "Terrain" },
                          {"ID": 3, "TextID": "ymap", "serviceName":"Yahoo", "layerDir": "yahoomap", "layerName": "Map" },
                          {"ID": 4, "TextID": "yter", "serviceName":"Yahoo", "layerDir": "yahooter", "layerName": "Terrain" },
                          {"ID": 5, "TextID": "vemap", "serviceName":"Virtual Earth", "layerDir": "vemap", "layerName": "Map" },
                          {"ID": 6, "TextID": "vesat", "serviceName":"Virtual Earth", "layerDir": "vesat", "layerName": "Satellite" },
                          {"ID": 7, "TextID": "veter", "serviceName":"Virtual Earth", "layerDir": "veter", "layerName": "Terrain" },
                          {"ID": 8, "TextID": "osmmap", "serviceName":"OpenStreetMap", "layerDir": "osmtiles", "layerName": "Map" },
                          {"ID": 9, "TextID": "cmmap", "serviceName":"CloudMade", "layerDir": "cloudmatetiles", "layerName": "Map" },
                          {"ID": 10, "TextID": "ifwmap", "serviceName":"InformationFreeway", "layerDir": "ifwtiles", "layerName": "Map" },
                          {"ID": 11, "TextID": "ocmmap", "serviceName":"OpenCycleMap", "layerDir": "ocmtiles", "layerName": "Map" },
                          {"ID": 12, "TextID": "gmmmap", "serviceName":"Google Map Maker", "layerDir": "gmmtiles", "layerName": "Map" }
                          ]
             */

            lr = new LayerInfo(0, "gmap", "Google", "tiles", "Map");
            layerDir_layer.Add(lr.LayerDir, lr);
            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(1, "gsat", "Google", "sat_tiles", "Satellite");
            layerDir_layer.Add(lr.LayerDir, lr);
            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(2, "gter", "Google", "ter_tiles", "Terrain");
            layerDir_layer.Add(lr.LayerDir, lr);
            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(3, "ymap", "Yahoo", "yahoomap", "Map");
            layerDir_layer.Add(lr.LayerDir, lr);
            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(4, "yter", "Yahoo", "yahooter", "Terrain");
            layerDir_layer.Add(lr.LayerDir, lr);
            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(5, "vemap", "Virtual Earth", "vemap", "Map" );
            layerDir_layer.Add(lr.LayerDir, lr);
            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(6, "vesat", "Virtual Earth", "vesat", "Satellite" );
            layerDir_layer.Add(lr.LayerDir, lr);
            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(7, "veter", "Virtual Earth", "veter", "Terrain");
            layerDir_layer.Add(lr.LayerDir, lr);
            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(8, "osmmap", "OpenStreetMap", "osmtiles", "Map");
            layerDir_layer.Add(lr.LayerDir, lr);
            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(9, "cmmap", "CloudMade", "cloudmatetiles", "Map");
            layerDir_layer.Add(lr.LayerDir, lr);
            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(10, "ifwmap", "InformationFreeway", "ifwtiles", "Map" );
            layerDir_layer.Add(lr.LayerDir, lr);
            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(11, "ocmmap", "OpenCycleMap", "ocmtiles", "Map");
            layerDir_layer.Add(lr.LayerDir, lr);
            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(12, "gmmmap", "Google Map Maker", "gmmtiles", "Map");
            layerDir_layer.Add(lr.LayerDir, lr);
            layerId_layer.Add(lr.Id, lr);
        }

        public static string getRepositoryTypeName(string path)
        {
            if (File.Exists(path + "\\" + form1.sqliteTilesRepository))
            {
                return "SQLite";
            }
            else
            {
                return "Files";
            }
        }

        public static ITileRepos getTileRepository(form1 f)
        {
            try
            {
                if( getRepositoryTypeName(f.getSelectedMapPath()).Equals("SQLite") )
                {
                    return new TileReposSQLite(f);
                }
                else
                {
                    return new TileReposFS(f);
                }
            }
            catch (NullReferenceException)
            {
                return new TileReposFS(f);
            }
        }
    }



}
