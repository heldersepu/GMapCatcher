﻿using System;

using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WMGooglemaps
{
    public partial class FormSelectMap : Form
    {
        private string selectedMap;
        private bool isSelectedMap;
        private form1 f1;

        private Hashtable btndirname_btn;

        public string SelectedMap
        {
            get { return selectedMap; }
        }

        public bool IsSelectedMap
        {
            get { return isSelectedMap; }
        }

        public FormSelectMap(form1 parent)
        {
            InitializeComponent();

            f1 = parent;
            selectedMap = null;
            isSelectedMap = false;

            showMapSelects();
        }

        private void bcancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void showMapSelects()
        {
            int xofs = 10;
            int yofs = 20;


            btndirname_btn = new Hashtable();

            string dir = f1.getMapsRootPath();
            ArrayList mapDirs = new ArrayList(System.IO.Directory.GetDirectories(f1.getMapsRootPath()));

            int index = 0;
            int space = 41;
            int btnheight = 30;
            foreach (string s in mapDirs)
            {
                string lastDirPart = s.Substring(s.LastIndexOf("\\") + 1);
                string rtype = TileReposFactory.getRepositoryTypeName(f1.getMapsRootPath() + "\\" + lastDirPart);

                Button btn = new System.Windows.Forms.Button();
                
                btn.Location = new Point(xofs, yofs + index * space);
                btn.Width = panelSelectMap.Width - 20;
                btn.Height = btnheight;

                btn.Text = lastDirPart + " (" + rtype + ")";
                panelSelectMap.Controls.Add(btn);
                btn.Click += new System.EventHandler(this.panelSelectMapButton_Click);

                btndirname_btn.Add(btn, lastDirPart);

                index++;
            }

            panelSelectMap.Visible = true;
        }

        private void panelSelectMapButton_Click(object sender, EventArgs e)
        {
            //selectedMap = ((Control)sender).Text;
            selectedMap = (string)btndirname_btn[(Button)sender];
            isSelectedMap = true;
            Close();
        }

    }
}