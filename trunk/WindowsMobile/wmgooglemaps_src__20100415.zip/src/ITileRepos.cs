﻿using System;
using System.Collections;
using System.Text;
using System.Drawing;

namespace WMGooglemaps
{
    interface ITileRepos
    {
        //public string TilesDirsCurrent;
        //public string ReposID;

        ArrayList getLayers();
        void setTilesLayer();   // set any layer
        void setTilesLayer(string layerText); //set layer
        Bitmap getTile(int lzoom, int ltilex, int ltiley);
        string getTilesDirsCurrent();
        string getReposID();
        string getLayerTextID();
        bool isInitialized();
    }
}
