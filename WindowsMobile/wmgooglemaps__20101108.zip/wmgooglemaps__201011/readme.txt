
This is readme file for wmgooglemaps.
author: standa31415
date: 2010/11/08


MD5Sums:
4e5f62adf0a9f7f7736c605a457f6d68  wmgooglemaps_src__20100415.zip
64c36d6a45dac4117e0d3fef863027af  wmgooglemaps_distr__20101108.zip

My intention is to distribute it under GPL.

Few notices / known issues:

I don't have access to development environment so I can't make changes to the code right now. There are several issues that can be fixed quite fast but not for me. Even though some bugs need to be fixed I decided to provide current version to the public.

Im using the tool while on trips/treks to mountains. As far as I can tell GPS is accurate.


WMGoogleMaps:
- name evokes it shows Google Maps. Not true. It show tiles from GMapCatcher map repositories. It could be yahoo, openstreetmap, cloudmade,...
- device doesn't work with online access. All tiles displayed in the device must be downloaded/cached in tiles repository before repository is copied to the device.
- supported repos types - SQLite3 and Files. Recommend SQLite3 because storage card is not filled with lot of small image files.

Available options / features:
- there are 6 buttons on the screen: zoom+ (num+), zoom- (num-), double size (o), lock GPS (G), show GPS state (P), waypoints (W)
- double size - resizes map 2x. It shows whats on the screen but twice as big. I have device with so high PPI, that names in the map are almost not readable. 2x shows everything twice in size.
- lock GPS - when GPS is on and device knows it's position the button is (usually) light blue. After selecting it turns blue and the current GPS position is centered on the map on device. Whenever map is panned it is centered by itself on next GPS update.
- show GPS state - GPS status is displayed. Whether GPS is on/off, lat, lon and number of sattelites found
- waypoints - shows window where it's possible to set whether all waypoints from waypoints file (see menu Options - Save GPS coord) or only selected categories of waypoints should be displayed on the map. It is also possible to select waypoint from the drop-down button and 'go' - centers map on the waypoint.

- Menu 'Options'
- Switch GPS On / Off
- Select Map - selects another map repository (repositories are in '<storage card>\wmgooglemaps\maps\'). Name of the directory with map repository is considered 'map name'.
- Show / Hide GPS coords - shows GPS coords for the middle of the screen
- Save GPS coord - saves the GPS coordinates of the center of the screen into waypoints file. It is possible to set name, some note (not used yet, but its saved in the file), set Tp (Tp = category / type of waypoint) and color used for viewing. Time and lat/lon is possible to override. If name is not set current time will be used instead. 
- Landscape / Portrait - switches screen orientation
- layer 1, layer 2,... - each layer in tiles repository has its own item here. Selecting it, layer is displayed. The names of layers are not displayed correctly. For examlpe it show Google map for layer that is Yahoo map.

Supported systems:
- Windows Mobile 6.5
- Windows Mobile 6.0 (maybe)
I have HTC with Windows Mobile 6.5. Don't have opportunity to test on any other device.

Installation:
- unzip 'wmgooglemaps_distr__20101108.zip' and copy 'wmgooglemaps' to the root directory of storage card.
- start wmgooglemaps.exe
- device asks if you really want to run this file
- map 'world' is part of the distribution. It has tiles of the world in maps and sattelite layers with zoom levels 17 and 16. Any other zoom level shows 'missing tile'

Adding new map:
- in gmapcatcher look at 'settings' at 'Custom Maps Directory'. Copy the directory to the storage card to the directory '<storage card>\wmgooglemaps\maps\' and start wmgooglemaps.
- in menu 'Options' select 'Select map'. New map should be listed in the window.
- when new map is first time opened/selected or map was updated and copied to the device and it is SQLite3 type it can take some time before map is displayed. Device looks like it does nothing and seems to be frozen. It is not. 
Why? Because device scans over all tiles in repository and try to find all different layers used. It can take several minutes. For repository 400MB expect to wait up to 2min. After scan finishes information about repository (num of layers and repository size in bytes) is saved into cache file in maps directory. When the map is opened afterwards the information is read from the cache file and start is fast.



Known issues -  bugs:

- name of last opened map is stored in '<storage card>\wmgooglemaps\lastmap.txt'. The map name is directory name of the map repository. For example for map: '<storage card>\wmgooglemaps\maps\world' the file '<storage card>\wmgooglemaps\lastmap.txt' contains single line: 'world' (without quotes).
If file '<storage card>\wmgooglemaps\lastmap.txt' doesn't exist or map was deleted/renamed, so the directory '<storage card>\wmgooglemaps\maps\' + (name in '<storage card>\wmgooglemaps\lastmap.txt') doesn't exists the application exits with error with no option to select another map. 
Only solution is edit file '<storage card>\wmgooglemaps\lastmap.txt' and set existing map or rename map so the name in '<storage card>\wmgooglemaps\lastmap.txt' is valid.

- if map is copied directly from gmapcatcher the map repository directory doesn't contain file 'lastposition.txt'. The file contains layer, zoom level and lat/lon for the map when it was closed. When such map is opened wmgooglemaps behave 'crazy'. It shows repeatedly error. When error message is closed another error is displayed.
This inconsistency (GMapCatcher / wmgooglemaps) should be solved in next versions.
Solution: 
a) try to somehow close the wmgooglmaps by repeatedly trying to hit 'close'. On next start the file will be there and map shows correctly.
b) copy existing file 'lastposition.txt' from some other map before map is opened.

- on some occasion while GPS is switched off the app hangs. It stops responding. 
Solution: the only successful solution is to restart device :(
I believe it is deadlock. The code is based on windows mobile example. I think I know where the problem is but i'm not sure and I have no dev environment. For me it is the most annoying error but I am unable to fix it right now.

- on some occasion while panning/zooming wmgooglemaps is not able to open tile because OutOfMemory error. Just close the error message and pan map, the tile should be opened correctly on next occasion. In my case it always is.

- it happened that data for some tile was downloaded incorrectly. So image itself stored in tiles repository is invalid. It happened to me only twice on really slow internet connection. I think problem was with internet connection and not gmapcatcher but I am not sure and I'm unable to reproduce the state. While displaying the tile in gmapcatcher it was half black. Top of tile was OK, but bottom half was black, data were missing. GMapCatcher had no problem processing data but wmgooglemaps has problem. It shows error repeatedly. I was able to get rid of error by trying to close error message and switch the zoom layer. It seems there is problem with image library used by wmgooglemaps (windows mobile?). To get rid of error it is required to re-download the tile.

- waypoints file is not compatible with GMapCatcher. This inconsistency (GMapCatcher / wmgooglemaps) should be solved in next versions.




The end of readme.txt


