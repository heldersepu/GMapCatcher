﻿using System;

using System.Collections.Generic;
using System.Text;

namespace WMobileMaps
{
    class RepositoryException : Exception
    {
        Exception parent = null;
        public RepositoryException()
            : base()
        {
        }
        public RepositoryException(string s) : base(s)
        {
        }
        public RepositoryException(string s, Exception e)
            : base(s, e)
        {
            parent = e;
        }

    }

    class RepositoryNotExistsException : RepositoryException
    {
        Exception parent = null;
        public RepositoryNotExistsException()
            : base()
        {
        }
        public RepositoryNotExistsException(string s)
            : base(s)
        {
        }
        public RepositoryNotExistsException(string s, Exception e)
            : base(s, e)
        {
            parent = e;
        }
    }

    class RepositoryOtherException : RepositoryException
    {
        Exception parent = null;
        public RepositoryOtherException()
            : base()
        {
        }
        public RepositoryOtherException(string s)
            : base(s)
        {
        }
        public RepositoryOtherException(string s, Exception e)
            : base(s, e)
        {
            parent = e;
        }
    }

    class TileNotFoundException : RepositoryException
    {
        Exception parent = null;
        public TileNotFoundException()
            : base()
        {
        }
        public TileNotFoundException(string s) : base(s)
        {
        }
        public TileNotFoundException(string s, Exception e)
            : base(s, e)
        {
            parent = e;
        }
    }

    class RepositoryNotInitializedException : RepositoryException
    {
        Exception parent = null;
        public RepositoryNotInitializedException()
            : base()
        {
        }
        public RepositoryNotInitializedException(string s) : base(s)
        {
        }
        public RepositoryNotInitializedException(string s, Exception e)
            : base(s, e)
        {
            parent = e;
        }
    }

    class LayerNotExistsException : RepositoryException
    {
        Exception parent = null;
        public LayerNotExistsException()
            : base()
        {
        }
        public LayerNotExistsException(string s)
            : base(s)
        {
        }
        public LayerNotExistsException(string s, Exception e)
            : base(s, e)
        {
            parent = e;
        }
    }



}
