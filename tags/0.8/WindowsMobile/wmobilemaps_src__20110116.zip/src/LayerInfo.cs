﻿using System;

using System.Collections.Generic;
using System.Text;

namespace WMobileMaps
{
    internal class LayerInfo
    {
        /*
          {"ID": 0, "TextID": "gmap", "serviceName":"Google", "layerDir": "tiles", "layerName": "Map" },
          {"ID": 1, "TextID": "gsat", "serviceName":"Google", "layerDir": "sat_tiles", "layerName": "Satellite" },
          {"ID": 2, "TextID": "gter", "serviceName":"Google", "layerDir": "ter_tiles", "layerName": "Terrain" },
         */

        int id;
        string textID;
        string serviceName;
        string layerDir;
        string layerName;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public string TextID
        {
            get { return textID; }
            set { textID = value; }
        }
        public string ServiceName
        {
            get { return serviceName; }
            set { serviceName = value; }
        }
        public string LayerDir
        {
            get { return layerDir; }
            set { layerDir = value; }
        }
        public string LayerName
        {
            get { return layerName; }
            set { layerName = value; }
        }


        public LayerInfo(int id, string textID, string serviceName, string layerDir, string layerName)
        {
            this.id = id;
            this.textID = textID;
            this.serviceName = serviceName;
            this.layerDir = layerDir;
            this.layerName = layerName;
        }

        public string getLayerMenuText()
        {
            return textID;
        }
    }
}
