﻿using System;

using System.Collections;
using System.Text;
using System.IO;

namespace WMobileMaps
{
    internal class TileReposFactory
    {

        static Hashtable layerDir_layer;
        static Hashtable layerId_layer;

        public static Hashtable getLayerDir_layer()
        {
            return layerDir_layer;
        }
        public static Hashtable getLayerId_layer()
        {
            return layerId_layer;
        }
        /*
        public static ArrayList getCurrentLayers()
        {
            return currentLayers;
        }
         */
        
        static TileReposFactory()
        {
            LayerInfo lr;
            layerDir_layer = new Hashtable();
            layerId_layer = new Hashtable();

            /*
             * 20110107:
    {"ID": LAYER_MAP, "IDM": 0, "TextID": "gmap",  "serviceName":MAP_SERVERS[GOOGLE],            "layerDir": "tiles",     "layerName": LAYER_NAMES[LAYER_MAP] },
    {"ID": LAYER_SATELLITE, "IDM": 1, "TextID": "gsat",  "serviceName":MAP_SERVERS[GOOGLE],            "layerDir": "sat_tiles", "layerName": LAYER_NAMES[LAYER_SATELLITE] },
    {"ID": LAYER_TERRAIN, "IDM": 2, "TextID": "gter",  "serviceName":MAP_SERVERS[GOOGLE],            "layerDir": "ter_tiles", "layerName": LAYER_NAMES[LAYER_TERRAIN] },
    {"ID": LAYER_HYBRID, "IDM": 3, "TextID": "ghyb",  "serviceName":MAP_SERVERS[GOOGLE],            "layerDir": "hyb_tiles", "layerName": LAYER_NAMES[LAYER_HYBRID]},

    {"ID": LAYER_MAP, "IDM": 4, "TextID": "ymap",  "serviceName":MAP_SERVERS[YAHOO],            "layerDir": "yahoomap", "layerName": LAYER_NAMES[LAYER_MAP] },
    {"ID": LAYER_SATELLITE, "IDM": 5, "TextID": "yter",  "serviceName":MAP_SERVERS[YAHOO],            "layerDir": "yahooter", "layerName": LAYER_NAMES[LAYER_SATELLITE] },
    {"ID": LAYER_HYBRID, "IDM": 6, "TextID": "yhyb",  "serviceName":MAP_SERVERS[YAHOO],            "layerDir": "yahoohyb", "layerName": LAYER_NAMES[LAYER_HYBRID] },

    {"ID": LAYER_MAP, "IDM": 7, "TextID": "vemap", "serviceName":MAP_SERVERS[VIRTUAL_EARTH],            "layerDir": "vemap",    "layerName": LAYER_NAMES[LAYER_MAP] },
    {"ID": LAYER_SATELLITE, "IDM": 8, "TextID": "vesat", "serviceName":MAP_SERVERS[VIRTUAL_EARTH],            "layerDir": "vesat",    "layerName": LAYER_NAMES[LAYER_SATELLITE] },
    {"ID": LAYER_TERRAIN, "IDM": 9, "TextID": "veter", "serviceName":MAP_SERVERS[VIRTUAL_EARTH],            "layerDir": "veter",    "layerName": LAYER_NAMES[LAYER_TERRAIN] },

    {"ID": LAYER_MAP, "IDM": 10, "TextID": "osmmap", "serviceName":MAP_SERVERS[OSM],            "layerDir": "osmTiles", "layerName": ""},
    {"ID": LAYER_MAP, "IDM": 11, "TextID": "cmmap",  "serviceName":MAP_SERVERS[CLOUDMADE],            "layerDir": "cloudmadeTiles", "layerName": "" },
    {"ID": LAYER_MAP, "IDM": 12, "TextID": "ifwmap", "serviceName":MAP_SERVERS[INFO_FREEWAY],            "layerDir": "ifwTiles", "layerName": "" },
    {"ID": LAYER_MAP, "IDM": 13, "TextID": "ocmmap", "serviceName":MAP_SERVERS[OPENCYCLEMAP],            "layerDir": "ocmTiles", "layerName": ""},
    {"ID": LAYER_MAP, "IDM": 14, "TextID": "gmmmap", "serviceName":MAP_SERVERS[GOOGLE_MAKER],            "layerDir": "gmmTiles", "layerName": "" },
    {"ID": LAYER_MAP, "IDM": 15, "TextID": "yandexmap", "serviceName":MAP_SERVERS[YANDEX],            "layerDir": "yandexTiles", "layerName": "" },
    #Seznam.cz base
    {"ID": LAYER_MAP, "IDM": 16, "TextID": "seznam_base", "serviceName": MAP_SERVERS[SEZNAM],            "layerDir": "seznambase", "layerName": "Mapa" },
    {"ID": LAYER_SATELLITE, "IDM": 17, "TextID": "seznam_satellite", "serviceName":MAP_SERVERS[SEZNAM],            "layerDir": "seznamsat", "layerName": "Letecká" },
    {"ID": LAYER_TERRAIN, "IDM": 18, "TextID": "seznam_terrain", "serviceName": MAP_SERVERS[SEZNAM],            "layerDir": "seznamter", "layerName": "Stínování" },
    {"ID": LAYER_HYBRID, "IDM": 19, "TextID": "seznam_hybrid", "serviceName": MAP_SERVERS[SEZNAM],            "layerDir": "seznamhybrid", "layerName": "Popisy" },
    #Seznam.cz hiking
    {"ID": LAYER_SATELLITE, "IDM": 20, "TextID": "seznam_hiking", "serviceName": MAP_SERVERS[SEZNAM_HIKING],            "layerDir": "seznamhiking", "layerName": "Mapa" },
    {"ID": LAYER_TERRAIN, "IDM": 21, "TextID": "seznam_terrain", "serviceName": MAP_SERVERS[SEZNAM_HIKING],            "layerDir": "seznamter", "layerName": "Stínování" },
    {"ID": LAYER_HYBRID, "IDM": 22, "TextID": "seznam_hiking_routes", "serviceName": MAP_SERVERS[SEZNAM_HIKING],            "layerDir": "seznamhikingroutes", "layerName": "Trasy" },
    #Seznam.cz cyclo
    {"ID": LAYER_SATELLITE, "IDM": 23, "TextID": "seznam_cyclo", "serviceName": MAP_SERVERS[SEZNAM_CYCLO],            "layerDir": "seznamcyclo", "layerName": "Mapa" },
    {"ID": LAYER_TERRAIN, "IDM": 24, "TextID": "seznam_terrain", "serviceName": MAP_SERVERS[SEZNAM_CYCLO],            "layerDir": "seznamter", "layerName": "Stínování" },
    {"ID": LAYER_HYBRID, "IDM": 25, "TextID": "seznam_cyclo_routes", "serviceName": MAP_SERVERS[SEZNAM_CYCLO],            "layerDir": "seznamcycloroutes", "layerName": "Trasy" },
    #Seznam.cz historical
    {"ID": LAYER_SATELLITE, "IDM": 26, "TextID": "seznam_hist", "serviceName": MAP_SERVERS[SEZNAM_HIST],            "layerDir": "seznamhist", "layerName": "Mapa" },
    {"ID": LAYER_TERRAIN, "IDM": 27, "TextID": "seznam_terrain", "serviceName": MAP_SERVERS[SEZNAM_HIST],            "layerDir": "seznamter", "layerName": "Stínování" },
    {"ID": LAYER_HYBRID, "IDM": 28, "TextID": "seznam_hybrid", "serviceName": MAP_SERVERS[SEZNAM_HIST],            "layerDir": "seznamhybrid", "layerName": "Popisy" },
             */

            lr = new LayerInfo(0, "gmap", "Google", "tiles", "Map");            layerDir_layer.Add(lr.LayerDir, lr);            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(1, "gsat", "Google", "sat_tiles", "Satellite");            layerDir_layer.Add(lr.LayerDir, lr);            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(2, "gter", "Google", "ter_tiles", "Terrain");            layerDir_layer.Add(lr.LayerDir, lr);            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(3, "ghyb", "Google", "hyb_tiles", "Hybrid");            layerDir_layer.Add(lr.LayerDir, lr);            layerId_layer.Add(lr.Id, lr);

            lr = new LayerInfo(4, "ymap", "Yahoo", "yahoomap", "Map");            layerDir_layer.Add(lr.LayerDir, lr);            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(5, "yter", "Yahoo", "yahooter", "Terrain");            layerDir_layer.Add(lr.LayerDir, lr);            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(6, "yhyb", "Yahoo", "yahoohyb", "Hybrid");            layerDir_layer.Add(lr.LayerDir, lr);            layerId_layer.Add(lr.Id, lr);
            
            lr = new LayerInfo(7, "vemap", "Virtual Earth", "vemap", "Map");            layerDir_layer.Add(lr.LayerDir, lr);            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(8, "vesat", "Virtual Earth", "vesat", "Satellite" );            layerDir_layer.Add(lr.LayerDir, lr);            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(9, "veter", "Virtual Earth", "veter", "Terrain");            layerDir_layer.Add(lr.LayerDir, lr);            layerId_layer.Add(lr.Id, lr);

            lr = new LayerInfo(10, "osmmap", "OpenStreetMap", "osmtiles", "Map");            layerDir_layer.Add(lr.LayerDir, lr);            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(11, "cmmap", "CloudMade", "cloudmatetiles", "Map");            layerDir_layer.Add(lr.LayerDir, lr);            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(12, "ifwmap", "InformationFreeway", "ifwtiles", "Map" );            layerDir_layer.Add(lr.LayerDir, lr);            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(13, "ocmmap", "OpenCycleMap", "ocmtiles", "Map");            layerDir_layer.Add(lr.LayerDir, lr);            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(14, "gmmmap", "Google Map Maker", "gmmtiles", "Map");            layerDir_layer.Add(lr.LayerDir, lr);            layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(15, "yandexmap", "Yandex", "yandexTiles", "Map"); layerDir_layer.Add(lr.LayerDir, lr); layerId_layer.Add(lr.Id, lr);

            lr = new LayerInfo(16, "seznam_base", "Seznam", "seznambase", "Map"); layerDir_layer.Add(lr.LayerDir, lr); layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(17, "seznam_satellite", "Seznam", "seznamsat", "Letecka"); layerDir_layer.Add(lr.LayerDir, lr); layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(18, "seznam_terrain", "Seznam", "seznamter", "Stinovani"); layerDir_layer.Add(lr.LayerDir, lr); layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(19, "seznam_hybrid", "Seznam", "seznamhybrid", "Popisy"); layerDir_layer.Add(lr.LayerDir, lr); layerId_layer.Add(lr.Id, lr);

            lr = new LayerInfo(20, "seznam_hiking", "SeznamHike", "seznamhiking", "Mapa"); layerDir_layer.Add(lr.LayerDir, lr); layerId_layer.Add(lr.Id, lr);
            //lr = new LayerInfo(18, "seznam_terrain", "SeznamHike", "seznamter", "Stinovani"); layerDir_layer.Add(lr.LayerDir, lr); layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(22, "seznam_hiking_routes", "SeznamHike", "seznamhikingroutes", "Trasy"); layerDir_layer.Add(lr.LayerDir, lr); layerId_layer.Add(lr.Id, lr);

            lr = new LayerInfo(23, "seznam_cyclo", "SeznamBike", "seznamcyclo", "Mapa"); layerDir_layer.Add(lr.LayerDir, lr); layerId_layer.Add(lr.Id, lr);
            //lr = new LayerInfo(18, "seznam_terrain", "SeznamBike", "seznamter", "Stinovani"); layerDir_layer.Add(lr.LayerDir, lr); layerId_layer.Add(lr.Id, lr);
            lr = new LayerInfo(25, "seznam_cyclo_routes", "SeznamBike", "seznamcycloroutes", "Trasy"); layerDir_layer.Add(lr.LayerDir, lr); layerId_layer.Add(lr.Id, lr);

            lr = new LayerInfo(26, "seznam_hist", "SeznamHist", "seznamhist", "Mapa"); layerDir_layer.Add(lr.LayerDir, lr); layerId_layer.Add(lr.Id, lr);
            //lr = new LayerInfo(18, "seznam_terrain", "SeznamHist", "seznamter", "Stinovani"); layerDir_layer.Add(lr.LayerDir, lr); layerId_layer.Add(lr.Id, lr);
            // WTF ?? lr = new LayerInfo(28, "seznam_hybrid", "SeznamHist", "seznamhybrid", "Popisy"); layerDir_layer.Add(lr.LayerDir, lr); layerId_layer.Add(lr.Id, lr);
        }

        public static string getRepositoryTypeName(string path)
        {
            if (File.Exists(path + "\\" + form1.sqliteTilesRepository))
            {
                return "SQLite";
            }
            else
            {
                return "Files";
            }
        }

        public static ITileRepos getTileRepository(form1 f)
        {
            try
            {
                if( getRepositoryTypeName(f.getSelectedMapPath()).Equals("SQLite") )
                {
                    return new TileReposSQLite(f);
                }
                else
                {
                    return new TileReposFS(f);
                }
            }
            catch (NullReferenceException)
            {
                return new TileReposFS(f);
            }
        }
    }



}
