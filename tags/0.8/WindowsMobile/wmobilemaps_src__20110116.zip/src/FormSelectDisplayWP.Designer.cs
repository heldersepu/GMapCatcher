﻿namespace WMobileMaps
{
    partial class FormSelectDisplayWP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.label1 = new System.Windows.Forms.Label();
            this.rb_none = new System.Windows.Forms.RadioButton();
            this.rb_selected = new System.Windows.Forms.RadioButton();
            this.rb_all = new System.Windows.Forms.RadioButton();
            this.bok = new System.Windows.Forms.Button();
            this.panelcb = new System.Windows.Forms.Panel();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.cb_gotowaypoint = new System.Windows.Forms.ComboBox();
            this.b_gotowaypoint = new System.Windows.Forms.Button();
            this.cbdummy = new System.Windows.Forms.ComboBox();
            this.panelcb.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(3, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(234, 20);
            this.label1.Text = "Select WayPoints for Display:";
            // 
            // rb_none
            // 
            this.rb_none.Location = new System.Drawing.Point(4, 37);
            this.rb_none.Name = "rb_none";
            this.rb_none.Size = new System.Drawing.Size(64, 20);
            this.rb_none.TabIndex = 1;
            this.rb_none.Text = "None";
            this.rb_none.CheckedChanged += new System.EventHandler(this.rb_none_CheckedChanged);
            // 
            // rb_selected
            // 
            this.rb_selected.Location = new System.Drawing.Point(64, 37);
            this.rb_selected.Name = "rb_selected";
            this.rb_selected.Size = new System.Drawing.Size(90, 20);
            this.rb_selected.TabIndex = 2;
            this.rb_selected.Text = "Selected";
            this.rb_selected.CheckedChanged += new System.EventHandler(this.rb_selected_CheckedChanged);
            // 
            // rb_all
            // 
            this.rb_all.Location = new System.Drawing.Point(148, 37);
            this.rb_all.Name = "rb_all";
            this.rb_all.Size = new System.Drawing.Size(45, 20);
            this.rb_all.TabIndex = 3;
            this.rb_all.Text = "All";
            this.rb_all.CheckedChanged += new System.EventHandler(this.rb_all_CheckedChanged);
            // 
            // bok
            // 
            this.bok.Location = new System.Drawing.Point(199, 33);
            this.bok.Name = "bok";
            this.bok.Size = new System.Drawing.Size(37, 24);
            this.bok.TabIndex = 4;
            this.bok.Text = "OK";
            this.bok.Click += new System.EventHandler(this.button1_Click);
            // 
            // panelcb
            // 
            this.panelcb.Controls.Add(this.cbdummy);
            this.panelcb.Controls.Add(this.checkBox1);
            this.panelcb.Location = new System.Drawing.Point(3, 63);
            this.panelcb.Name = "panelcb";
            this.panelcb.Size = new System.Drawing.Size(233, 158);
            // 
            // checkBox1
            // 
            this.checkBox1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.checkBox1.Location = new System.Drawing.Point(86, 105);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(90, 20);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "W";
            // 
            // cb_gotowaypoint
            // 
            this.cb_gotowaypoint.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.cb_gotowaypoint.Location = new System.Drawing.Point(3, 242);
            this.cb_gotowaypoint.Name = "cb_gotowaypoint";
            this.cb_gotowaypoint.Size = new System.Drawing.Size(190, 23);
            this.cb_gotowaypoint.TabIndex = 7;
            // 
            // b_gotowaypoint
            // 
            this.b_gotowaypoint.Location = new System.Drawing.Point(200, 241);
            this.b_gotowaypoint.Name = "b_gotowaypoint";
            this.b_gotowaypoint.Size = new System.Drawing.Size(37, 24);
            this.b_gotowaypoint.TabIndex = 8;
            this.b_gotowaypoint.Text = "Go";
            this.b_gotowaypoint.Click += new System.EventHandler(this.b_gotowaypoint_Click);
            // 
            // cbdummy
            // 
            this.cbdummy.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.cbdummy.Location = new System.Drawing.Point(51, 60);
            this.cbdummy.Name = "cbdummy";
            this.cbdummy.Size = new System.Drawing.Size(100, 23);
            this.cbdummy.TabIndex = 1;
            // 
            // FormSelectDisplayWP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.b_gotowaypoint);
            this.Controls.Add(this.cb_gotowaypoint);
            this.Controls.Add(this.bok);
            this.Controls.Add(this.panelcb);
            this.Controls.Add(this.rb_all);
            this.Controls.Add(this.rb_selected);
            this.Controls.Add(this.rb_none);
            this.Controls.Add(this.label1);
            this.Menu = this.mainMenu1;
            this.Name = "FormSelectDisplayWP";
            this.Text = "FormSelectDisplayWP";
            this.panelcb.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rb_none;
        private System.Windows.Forms.RadioButton rb_selected;
        private System.Windows.Forms.RadioButton rb_all;
        private System.Windows.Forms.Button bok;
        private System.Windows.Forms.Panel panelcb;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.ComboBox cb_gotowaypoint;
        private System.Windows.Forms.Button b_gotowaypoint;
        private System.Windows.Forms.ComboBox cbdummy;
    }
}