﻿using System;

using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace WMobileMaps
{
    public class WayPoint
    {

        public static string[] colorsNames = { 
"Black", 
"Blue", 
"Brown", 
"Cyan", 
"Green", 
"Magenta", 
"Orange", 
"Red", 
"Violet", 
"Yellow" 
                                             };

        static Color[] colorsColors = { 
Color.Black, 
Color.Blue, 
Color.Brown, 
Color.Cyan, 
Color.Green, 
Color.Magenta, 
Color.Orange, 
Color.Red, 
Color.Violet, 
Color.Yellow
                                       };

        public double latitude, longitude;
        public int zoom, px, py;
        public string name;
        public string note;
        public string tstamp;
        public string wptype;
        public Color color;

        public int size;

        public void setSize(int s)
        {
            size = s;
        }
        public int getSize()
        {
            return size;
        }
        public int getpx()
        {
            return px;
        }
        public int getpy()
        {
            return py;
        }
        public Color getColor()
        {
            return color;
        }
        public string getWPType()
        {
            return wptype;
        }
        public string getName()
        {
            return name;
        }
        public double getLatitude()
        {
            return latitude;
        }
        public double getLongitude()
        {
            return longitude;
        }
        public void setpx(int x)
        {
            px = x;
        }
        public void setpy(int y)
        {
            py = y;
        }

        public WayPoint(string atype, string aname, string anote, double alat, double alon, string acolor, string atstamp)
        {
            size = 2;
            latitude = alat;
            longitude = alon;
            name = aname;
            note = anote;
            tstamp = atstamp;
            wptype = atype;

            bool foundColor = false;
            for (int i = 0; i < colorsNames.Length; i++)
            {
                if (acolor.ToLower().Equals(colorsNames[i].ToLower()))
                {
                    color = colorsColors[i];
                    foundColor = true;
                    break;
                }
            }

            if (!foundColor)
            {
                color = colorsColors[0];
            }
            
        }

        public override string ToString()
        {
            return wptype + ": " + name;
        }
    }
}
