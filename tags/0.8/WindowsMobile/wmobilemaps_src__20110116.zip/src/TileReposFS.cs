﻿using System;

using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Collections;
using System.IO;

namespace WMobileMaps
{
    internal class TileReposFS : ITileRepos
    {
        Hashtable layerDir_layer;
        ArrayList currentLayers;
        LayerInfo currentLayer;

        bool initialized;

        form1 f;

        public TileReposFS(form1 f)
        {
            this.f = f;
            layerDir_layer = TileReposFactory.getLayerDir_layer();

            initialized = false;
            initTilesLayers();
        }

        ~TileReposFS()
        {
        }

        public ArrayList getLayers()
        {
            return currentLayers;
        }

        void initTilesLayers()
        {
            currentLayers = new ArrayList();
            ArrayList tilesDirs;

            try
            {
                string dirname = f.getSelectedMapPath();
                tilesDirs = new ArrayList(System.IO.Directory.GetDirectories(dirname));

                if (tilesDirs.Count == 0)
                    throw new Exception("No map directories in: '" + dirname + "'");

                foreach (string s in tilesDirs)
                {
                    string lastDirPart = s.Substring(s.LastIndexOf("\\") + 1);
                    LayerInfo l;
                    if (layerDir_layer.ContainsKey(lastDirPart))
                    {
                        l = (LayerInfo)layerDir_layer[lastDirPart];
                        currentLayers.Add(l);
                    }
                }

                initialized = true;
            }
            catch (NullReferenceException e)
            {
                initialized = false;
                throw new RepositoryNotInitializedException("Initialization error.", e);
            }
        }

        private string getTileFilename(int lzoom, int ltilex, int ltiley)
        {
            int xmaj = (ltilex) / 1024;
            int xmin = (ltilex) % 1024;
            int ymaj = (ltiley) / 1024;
            int ymin = (ltiley) % 1024;

            string tileFileName = f.getSelectedMapPath() + "\\" + currentLayer.LayerDir + "\\" + lzoom.ToString() + "\\" +
                            xmaj.ToString() + "\\" + xmin.ToString() + "\\" + ymaj.ToString() + "\\" + ymin.ToString() + ".png";
            return tileFileName;
        }

        public Bitmap getTile(int lzoom, int ltilex, int ltiley)
        {
            if (!initialized)
            {
                throw new RepositoryNotInitializedException("Not initialized.");
            }

            //string tileHash = ReposID + ":" + lzoom.ToString() + ":" + ltilex.ToString() + ":" + ltiley.ToString();

            string tileFileName = "";
            try
            {
                tileFileName = getTileFilename(lzoom, ltilex, ltiley);
                if (!File.Exists(tileFileName))
                {
                    throw new TileNotFoundException("Tile not found filename: " + tileFileName);
                }
            }
            catch (NullReferenceException)
            {
                // TODO: toto neni uplne ciste.
                throw new TileNotFoundException("Tile not found filename. Null reference.");
            }


            try
            {
                FileStream src = new FileStream(tileFileName, FileMode.Open);
                Bitmap btm = new Bitmap(src);
                src.Close();
                return btm;
            }
            catch (Exception e)
            {
                throw new RepositoryOtherException("Error: ", e);
            }

        }

        public void setTilesLayer(string textID)
        {
            if (!initialized)
            {
                throw new RepositoryNotInitializedException("Not initialized.");
            }

            foreach (LayerInfo li in currentLayers)
            {
                if (li.TextID.Equals(textID))
                {
                    currentLayer = li;
                    return;
                }
            }
            throw new LayerNotExistsException("Layer '" + textID + "' was not found!");
        }

        public void setTilesLayer()
        {
            if (!initialized)
            {
                throw new RepositoryNotInitializedException("Not initialized.");
            }

            foreach (LayerInfo li in currentLayers)
            {
                currentLayer = li;
                return;
            }
            throw new LayerNotExistsException("No layer was found!");
        }

        public string getTilesDirsCurrent()
        {
            if (!initialized)
            {
                throw new RepositoryNotInitializedException("Not initialized.");
            }

            return currentLayer.LayerDir;
        }

        public string getReposID()
        {
            if (!initialized)
            {
                return ":";
            }
            try
            {
                return f.getSelectedMapPath() + ":" + currentLayer.LayerDir;
            }
            catch (NullReferenceException)
            {
                return ":";
            }
        }

        public bool isInitialized()
        {
            return initialized;
        }

        public string getLayerTextID()
        {
            if (!initialized)
            {
                return "";
            }
            try
            {
                return currentLayer.TextID;
            }
            catch (NullReferenceException)
            {
                return "";
            }
        }
    }





}


