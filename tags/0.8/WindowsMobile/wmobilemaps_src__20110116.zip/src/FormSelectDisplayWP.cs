﻿using System;

using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

// for write to file widgets positions
using System.IO;

namespace WMobileMaps
{
    public partial class FormSelectDisplayWP : Form
    {
        ArrayList wayPointsCBList;
        form1 mainForm;
        String allWPTypes;
        String selectedWPTypes;
        bool finished_ok;
        bool finished_go;
        ArrayList waypoints;

        public FormSelectDisplayWP(form1 parent)
        {
            InitializeComponent();
            mainForm = parent;
            checkBox1.Visible = false;
            cbdummy.Visible = false;
            finished_go = false;
            finished_ok = false;

            //bok.Location = new System.Drawing.Point(this.Width - bok.Width - 10, this.Height - bok.Height - 20);
            cb_gotowaypoint.Location = new System.Drawing.Point(10, this.Height - cbdummy.Height - 20);
            b_gotowaypoint.Location = new System.Drawing.Point(this.Width - b_gotowaypoint.Width - 10, this.Height - cbdummy.Height - 20);

            panelcb.Width =  this.Width - panelcb.Location.X;
            panelcb.Height = b_gotowaypoint.Location.Y - panelcb.Location.Y - 10;

            selectedWPTypes = mainForm.getSelectedWPTypes().ToUpper();
            allWPTypes = mainForm.getAllWPTypes().ToUpper();

            if (!mainForm.isFlagDrawWayPoints())
            {
                rb_none.Checked = true;
                panelcb.Enabled = false;
            }
            else if (mainForm.isFlagDrawAllWayPoints())
            {
                rb_all.Checked = true;
                panelcb.Enabled = false;
            }
            else
            {
                rb_selected.Checked = true;
                panelcb.Enabled = true;
            }

            wayPointsCBList = new ArrayList(allWPTypes.Length);
            int lastcbX = -1;
            int lastcbY = 0;
            int cbHeight = checkBox1.Height;

            for (int idx = 0; idx < allWPTypes.Length; idx++)
            {
                CheckBox cb = new CheckBox();
                cb.Text = allWPTypes.Substring(idx, 1);
                cb.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);

                panelcb.Controls.Add(cb);
                wayPointsCBList.Add(cb);

                if (lastcbX == -1)
                {
                    // we have new CB
                    lastcbX = 10;
                    lastcbY = 10;
                }
                else
                {
                    lastcbY = lastcbY + 10 + checkBox1.Height;
                }

                if ((lastcbY + cbHeight + 10) > panelcb.Height)
                {
                    // we have second column
                    lastcbX = panelcb.Width / 2;
                        lastcbY = 10;
                }

                cb.Location = new System.Drawing.Point(lastcbX, lastcbY);
                cb.Width = 120;
                cb.Height = cbHeight;

                if (selectedWPTypes.IndexOf(allWPTypes.Substring(idx, 1)) > -1)
                {
                    cb.Checked = true;
                } 
                else 
                {
                    cb.Checked = false;
                }

            }


            // init combobox of all waypoints
            waypoints = mainForm.get_waypoints();
            if (waypoints.Count == 0)
            {
                b_gotowaypoint.Enabled = false;
                cb_gotowaypoint.Enabled = false;
            }
            else
            {
                foreach (WayPoint wp in waypoints)
                {
                    string text = wp.getWPType() + ": " + wp.getName();
                    cb_gotowaypoint.Items.Add(text);
                }
                cb_gotowaypoint.SelectedIndex = 0;
            }

            saveWidgetsPositionsToFile();
        }

        private string formatPositionString(Control ctrl)
        {
            return ctrl.Name + ":" + ctrl.Left + ":" + ctrl.Top + ":" + ctrl.Width + ":" + ctrl.Height+"\n";
        }

        private void saveWidgetsPositionsToFile()
        {
            // for debug purposes - store position of widgets
            try
            {
                //
                using (StreamWriter outfile =
                    new StreamWriter(mainForm.GooglemapsRootPath + "\\waypointsWidgets.txt"))
                {
                    outfile.Write(formatPositionString(rb_none));
                    outfile.Write(formatPositionString(rb_selected));
                    outfile.Write(formatPositionString(rb_all));
                    outfile.Write(formatPositionString(bok));
                    outfile.Write(formatPositionString(cb_gotowaypoint));
                    outfile.Write(formatPositionString(b_gotowaypoint));
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show("Unable to store widget positions.\n" + exc.ToString() + exc.StackTrace);
            }
        }



        private void button1_Click(object sender, EventArgs e)
        {
            finished_ok = true;
            Close();
        }

        public string getSelectedWPTypes()
        {
            String ret = "";
            foreach (CheckBox wp in wayPointsCBList)
            {
                if (wp.Checked)
                {
                    ret = ret + wp.Text.Substring(0, 1).ToUpper();
                }
            }
            return ret;
        }

        public bool isNoneSelected()
        {
            if (rb_none.Checked)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool isSelectedSelected()
        {
            if (rb_selected.Checked)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool isAllSelected()
        {
            if (rb_all.Checked)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void rb_none_CheckedChanged(object sender, EventArgs e)
        {
            panelcb.Enabled = false;
            //Close();
        }

        private void rb_selected_CheckedChanged(object sender, EventArgs e)
        {
            panelcb.Enabled = true;
        }

        private void rb_all_CheckedChanged(object sender, EventArgs e)
        {
            panelcb.Enabled = false;
            //Close();
        }

        private void b_gotowaypoint_Click(object sender, EventArgs e)
        {
            finished_go = true;
            Close();
        }

        public bool is_finished_go()
        {
            return finished_go;
        }
        public bool is_finished_ok()
        {
            return finished_ok;
        }

        public WayPoint get_selected_waypoint_for_go()
        {
            //int i = int.Parse(cb_gotowaypoint.SelectedIndex.ToString());
            return (WayPoint)waypoints[int.Parse(cb_gotowaypoint.SelectedIndex.ToString()) ];
        }

    }
}