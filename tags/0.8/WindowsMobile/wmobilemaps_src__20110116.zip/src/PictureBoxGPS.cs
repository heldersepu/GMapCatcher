﻿using System;

using System.Collections.Generic;
using System.Windows.Forms;
using System.Text;
using System.IO;
using System.Drawing;

namespace WMobileMaps
{
    class PictureBoxGPS : System.Windows.Forms.PictureBox
    {
        Bitmap gpsMarkerBitmap;

        public PictureBoxGPS(string gpsMarkerFileName)
            : base()
        {

            FileStream src = new FileStream(gpsMarkerFileName, FileMode.Open);
            gpsMarkerBitmap = new Bitmap(src);
            src.Close();
            this.Width = gpsMarkerBitmap.Width;
            this.Height = gpsMarkerBitmap.Height;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.DrawImage(gpsMarkerBitmap, 0, 0);

            // TODO: ma byt: g.Dispose(); ??
        }
    }
}
